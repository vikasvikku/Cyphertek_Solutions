# dataset > 2025-10-08 8:34pm
https://universe.roboflow.com/work-oodjp/dataset-ovwmx

Provided by a Roboflow user
License: CC BY 4.0

